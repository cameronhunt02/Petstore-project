﻿using System.Text.Json;
using System.Collections.Generic;

var productLogic = new ProductLogic();


Console.WriteLine("Press 1 to purchase Cat food");
Console.WriteLine("Press 2 to search for a dog leash");
Console.WriteLine("Type exit to quit");
string userInput = Console.ReadLine().ToLower();

while (userInput.ToLower() != "exit")
{
    if (userInput == "1")
    {
        CatFood item = new CatFood();
        Console.WriteLine("Press 1 for Cat Food or 2 Kitten food");
        string answer = Console.ReadLine();
        if (answer == "1")
        {
            item.KittenFood = false;
            
        }
        else if(answer == "2")
        {
                item.KittenFood = true;
               
            
        }
        Console.WriteLine("How many pounds do you need?");
        double weight = Double.Parse(Console.ReadLine());
        Console.WriteLine($"You need {weight} pounds of food, someone has a hungry kitty!");
        item.WeightPounds = weight;
        productLogic.AddProduct(item);
        Console.WriteLine("You have added a product!");


    }
    else if (userInput == "2")
    {
        Console.WriteLine("Enter the name of the leash");
        string leashName= Console.ReadLine();
        Console.WriteLine(productLogic.GetDogLeashByName(leashName));

        



    }
    Console.WriteLine("Press 1 to add a product");
    Console.WriteLine("Type exit to quit");
    userInput = Console.ReadLine();
    
}     


public class Product
{
    public string Name;
    public decimal Price;
    public int Quantity;
    public string Description;
}
public class CatFood : Product
{
    public double WeightPounds;
    public bool KittenFood;
}
public class DogLeash : Product
{
    public int LengthInches;
    public string Material;
}
public class ProductLogic
{
    List<Product> _products;
    Dictionary<string, DogLeash> _DogLeash1;
    Dictionary<string, CatFood> _CatFood1;
    
    public ProductLogic()
    {
        _products = new List<Product>();

    }
    public void AddProduct(Product product) 
    {
        if (product is DogLeash)
        {

            _DogLeash1.Add(product.Name, product as DogLeash);

        }
        else if (product is CatFood) {
            _CatFood1.Add(product.Name, product as CatFood);
        }
        _products.Add(product);
    }
    public DogLeash GetDogLeashByName(string name)
    {
        return _DogLeash1[name];
    }
    public List<Product> GetAllProducts() 
    {
        return _products;
    }
    



}


